package com.byte07.util;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author yanlixian
 * @date 2021/7/22 0:43
 **/
public class UserUtil {

    @Autowired
    private UserProperties userProperties;

    public String getUserInfo(){
        return userProperties.getAddress() + userProperties.getAge();
    }

}
