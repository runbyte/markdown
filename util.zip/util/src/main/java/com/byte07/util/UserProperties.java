package com.byte07.util;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author yanlixian
 * @date 2021/7/22 0:40
 **/
@Data
@ConfigurationProperties(prefix = "user")
public class UserProperties {

    private Integer age;

    private String address;

}
