package com.byte07.util;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author yanlixian
 * @date 2021/7/22 0:44
 **/
@Configuration
@EnableConfigurationProperties(UserProperties.class)
public class UserConfig {

    @Bean
    public UserUtil getUtil(){
        return new UserUtil();
    }

}
