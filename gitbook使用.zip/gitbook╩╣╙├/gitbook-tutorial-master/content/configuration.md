# 配置

这里主要讲 `book.json` 的配置及参数，gitbook 使用该文件来配置整本书的基本信息，结构，使用的插件等等信息，这是一个非常重要的配置文件。

这个配置文件使用 json 格式，配置非常简单，参考官方解释即可。

## reference

- <https://toolchain.gitbook.com/config.html>
