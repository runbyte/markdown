# 结语

Gitbook 初次尝试还是非常不错的，结合 Gitbook.com 网站能够快速托管自己的电子书。不管是用来自己做笔记还是真的用来写小说，或者正式的写作，大概是一个不错的代替方案。

关于 Markdown 的语法规则，可以参考 <http://einverne.github.io/markdown-style-guide/zh.html>

Gitbook 官方文档: <https://toolchain.gitbook.com/>
