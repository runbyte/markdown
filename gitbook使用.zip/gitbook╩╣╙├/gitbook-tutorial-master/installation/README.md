# 基本安装

这一章主要讲 Gitbook 的环境及安装，以及命令行的使用概览。

## 本地安装

在本地安装 gitbook 命令非常简单，本地系统需要依赖

- NodeJS v4.0 及以上
- 系统需要满足 Windows, Linux, Unix, or Mac OS X


