# 添加评论

插件地址: <https://plugins.gitbook.com/plugin/disqus>

```json
"plugins": [
    "disqus"
],
"pluginsConfig": {
    "disqus": {
        "shortName": "gitbook-tutorial"
    }
}
```