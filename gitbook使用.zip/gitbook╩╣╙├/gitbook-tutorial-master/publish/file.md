# 发布到文件

可以在本地运行如下命令来分别生成 pdf, epub, mobi 格式文件

- gitbook pdf .
- gitbook epub .
- gitbook mobi .

