# 发布

可以使用Github Pages服务将我们写的Gitbook发布到互联网上，前提是你已经了解了Git、Github及Github Pages的使用。
